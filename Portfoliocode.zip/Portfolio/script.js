console.log("script running...")
document.querySelector('.cross').computedStyleMap.display='none';
document.querySelector('.hamburger').addEventListener("Click",()=>{document.querySelector('.sidebarGo').classList.toggle('sidebarGo');
if(document.querySelector('.sidebar').classList.contains('sidebarGo')){ 
    document.querySelector('.ham').classList.toggle('inline')
    document.querySelector('.cross').classList.toggle('none')

}
else{
    document.querySelector('.ham').Style.display='none' 
    .setTimeout(()=>{
        document.querySelector('.cross').style.display='inline'},300);
    }
    
    // document.querySelector('.cross').classList.toggle('inline')



})